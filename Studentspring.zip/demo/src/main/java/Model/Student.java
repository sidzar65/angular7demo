package Model;

import java.util.Comparator;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This is the student Model and sort done by name
 * 
 * @author Fuzail Memon
 *
 */
@Entity
@Table(name = "student")
public class Student implements Comparator<Student> {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private int student_id;
	private String student_name;
	private String student_email;
	private String student_address;

	public String getStudent_address() {
		return student_address;
	}

	public void setStudent_address(String student_address) {
		this.student_address = student_address;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public String getStudent_name() {
		return student_name;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public String getStudent_email() {
		return student_email;
	}

	public void setStudent_email(String student_email) {
		this.student_email = student_email;
	}

	@Override
	public int compare(Student s1, Student s2) {
		return s1.getStudent_name().compareTo(s2.getStudent_name());

	}

}
