package DAO;

import java.util.List;

import Model.Student;

public interface Student_DAO {
	/**
	 * 
	 * @param student
	 * @return
	 */

	public boolean saveStudent(Student student);
	/**
	 * This method will get the student information
	 * @return
	 */

	public List<Student> getStudents();
	/**
	 * This method will delete the student data
	 * @param student
	 * @return
	 */

	public boolean deleteStudent(Student student);
	/**
	 * this will get the student by Id
	 * @param student
	 * @return
	 */

	public List<Student> getStudentByID(Student student);

	public boolean updateStudent(Student student);

}
