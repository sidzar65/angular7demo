package Service;

import java.util.List;
import Model.Student;

/**
 * 
 * @author Fuzail Memon
 *
 */

public interface Student_Service {
	/**
	 * This is the insert method for student data
	 * 
	 * @param student
	 * @return
	 */

	public boolean saveStudent(Student student);

	/**
	 * This get the student data
	 * 
	 * @return
	 */

	public List<Student> getStudents();

	/**
	 * This will delete the student
	 * 
	 * @param student
	 * @return
	 */
	public boolean deleteStudent(Student student);

	/**
	 * This method will get the student by id
	 * 
	 * @param student
	 * @return
	 */

	public List<Student> getStudentByID(Student student);

	/**
	 * This will update the student
	 * 
	 * @param student
	 * @return
	 */

	public boolean updateStudent(Student student);

}
